$str = join("",<STDIN>);
@matches = ();
push (@matches,"$2\t$1") while($str =~ /<A href="#" onClick='show_mgram\((\d{1,6})\)'>(.{1,35})<\/a>/g );
foreach (@matches) {
	@d = split("\t");
	open(R, "wget \"http://new.meteo.pl/um/php/meteorogram_id_um.php?ntype=0u&id=$d[1]\" 2>/dev/null -O - |")  or die "Couldn't fork: $!\n";
	while (<R>) { if ($_ =~ /var act_x = (\d+);var act_y = (\d+);/) {
		push(@d,$1);
		push(@d,$2);
	} }
	close(README);
	print "\tnew Array(\"$d[0]\", $d[1], $d[2], $d[3] ),\n";
	break;
}